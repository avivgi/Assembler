#ifndef __LANGUAGE_UTILS__
#define __LANGUAGE_UTILS__

#include <stdlib.h>
#include "../language.h"
#include "../datamodel.h"

int legalLabel(char *label_name, Symbol **symbols, size_t symbol_count, Data_model data_model);
#endif
