#ifndef __ASSEMBLER__
#define __ASSEMBLER__

int handleSourceFile(char *arg);
int main(int argc, char *argv[]);

#endif
