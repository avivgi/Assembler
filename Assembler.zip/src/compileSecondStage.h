#ifndef __COMPILE_SECOND_STAGE__
#define __COMPILE_SECOND_STAGE__

int compileSecondStage(const char *filename, Data_model *data_model);

#endif
