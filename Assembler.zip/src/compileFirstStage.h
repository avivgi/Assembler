#ifndef __COMPILE_FIRST_STAGE__
#define __COMPILE_FIRST_STAGE__
#include "datamodel.h"

int compileFirstStage(const char *filename, Data_model *data_model);
#endif
