#ifndef __COMPILE__
#define __COMPILE__

int compile(const char *filename);

#endif
