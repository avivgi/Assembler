#ifndef __UPDATEDATASYMBOLS
#define __UPDATEDATASYMBOLS
#include <stdlib.h>
#include <stdio.h>
#include "../datamodel.h"

void update_data_address(Data_model *data_model);

#endif
